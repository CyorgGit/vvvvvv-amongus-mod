Hello, thanks for installing my sussy mod.

Showcase: https://youtu.be/dHI2eunhPBg
I die a lot, but it's VVVVVV, so that's expected.

Only tested on Windows 10 with the Steam release of VVVVVV.

However, it may be possible in the future to hack the console
ports of VVVVVV to patch the images in. Whether this is
possible is unknown. I may try it in the future with my hacked 3DS,
which has VVVVVV installed.

How to install
------------------

1. Extract the "SUS.zip" archive. I'm assuming you already have because you're
reading this. 

2. Make a backup of your data.zip folder, rename it to whatever you want, 
and copy and paste it so you get a new folder.

3. Rename the new "data.zip" folder.

4. Copy the "sprites.png" image from the "SUS" folder.

5. Go to "data.zip/graphics".

6. Delete the old "sprites.png".

7. Paste the "sprites.png" you copied earlier

8. Launch "VVVVVV.exe" in the root directory of the game.

9. Continue your save or start a new one.

10. Suffer.


How to uninstall
--------------------

Don't see why you would uninstall, but here's how to.

1. Delete your modded "data.zip", and replace it with
your old backed up one.

2. That's it. Have fun.